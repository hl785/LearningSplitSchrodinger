import copy
import numpy as np
import matplotlib.pyplot as plt
import expsolve.fourier as fe
from textwrap import wrap

def subset(u, nRef, nRefMult):
    return u[0 + int(nRefMult / 2) : nRef - int(nRefMult / 2) : nRefMult]

def error(uMl, uRefSubset, xRange):
    return fe.l2norm(uRefSubset - uMl, xRange)**2

def plot(xRef, uRef, xMl, uMl, vRef, T, tMl, tRefMult, sampleRange, nMl, nRefMult, splitType, save = True, path = 'fig.svg'):
    plt.clf()
    
    plt.plot(xRef, np.abs(uRef), 'k', label='Ref Mod')
    plt.plot(xRef, np.real(uRef), 'b', label='Ref Real')
    plt.plot(xRef, np.imag(uRef), 'r', label='Ref Imag')

    plt.plot(xMl, np.abs(uMl), 'k.', label='Ml Mod')
    plt.plot(xMl, np.real(uMl), 'b.', label='Ml Real')
    plt.plot(xMl, np.imag(uMl), 'r.', label='Ml Imag')
    plt.legend()
    
    plt.twinx()
    plt.yscale('log')
    plt.plot(xRef, vRef + 26, color='yellow', alpha=.5)
    plt.fill_between(xMl, vRef + 26, 0, color='yellow', alpha=.1)
    
    uRefSubset = subset(uRef, nMl*nRefMult, nRefMult)
    
    txt=f'Length of time is {T} with temporal discretisation of {tMl} points (reference solution is {tRefMult} times finer). Spatial domain is [-{sampleRange}, {sampleRange}] with spatial/frequency discretisation of {nMl} points (reference solution is {nRefMult} times finer). Using splitting scheme "{splitType}" produced an error of {np.sqrt(error(uMl, uRefSubset, [-sampleRange, sampleRange]))}.'
    plt.title("\n".join(wrap(txt)))
    # plt.show(block = False)
    if save:
        plt.tight_layout()
        plt.savefig(path)
    else:
        plt.ion()
        plt.show()
        plt.pause(0.0001)

def plotFn(lossVals, params):
    itr = range(len(lossVals))
    plt.plot(itr, lossVals, 'k')
    plt.annotate(f'({itr[-1]}, {lossVals[-1]:-2.3})', xy=(itr[-1], lossVals[-1]), textcoords='data')
    plt.twinx()
    color = ['b', 'r']*(len(params)//2)
    newParams = copy.copy(params)
    newParams[::2] = params[:(len(params)//2)]
    newParams[1::2] = params[(len(params)//2):]
    bars = plt.bar(fe.grid1d(len(params), xrange=[0, itr[-1]]), newParams, itr[-1] / len(params), alpha=0.2, color = color, linewidth = 0.1)
    plt.show()