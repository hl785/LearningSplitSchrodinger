import expsolve.fourier as fe
import torch
import torch.nn as nn


@torch.jit.script
def paramTransform(gamma):
    # TODO: include symmetric, consistent and unconstrained
    numParams = len(gamma)
    numBeta = numParams // 2
    numAlpha = numParams - numBeta

    alpha = gamma[:numAlpha]
    beta = gamma[numAlpha:]

    alphaSum = torch.sum(alpha)
    betaSum = torch.sum(beta)

    a = torch.zeros(numParams + 2)
    b = torch.zeros(numParams + 2)

    if numAlpha == numBeta + 1:
        a[:numAlpha] = alpha
        a[numAlpha] = 1 - 2 * alphaSum
        a[(numAlpha + 1) :] = torch.flip(alpha, [0])

        b[:numBeta] = beta
        b[numBeta] = 0.5 - betaSum
        b[numBeta + 1] = 0.5 - betaSum
        b[(numBeta + 2) : numParams + 1] = torch.flip(beta, [0])

    elif numAlpha == numBeta:
        a[:numAlpha] = alpha
        a[numAlpha] = 0.5 - alphaSum
        a[numAlpha + 1] = 0.5 - alphaSum
        a[(numAlpha + 2) :] = torch.flip(alpha, [0])

        b[:numBeta] = beta
        b[numBeta] = 1 - 2 * betaSum
        b[(numBeta + 1) : numParams + 1] = torch.flip(beta, [0])

    else:
        assert False

    return a, b

@torch.jit.script
def lossFn(output, target):
    diff = output - target
    return torch.vdot(diff, diff).real


# potentialFlow associated with alpha
class PotFlow(nn.Module):
    def __init__(self, timeStep, potential):
        super().__init__()
        self.potentialScalExp = torch.exp(-1j * timeStep * potential)

    def forward(self, u, param):
        flow = torch.pow(self.potentialScalExp, param)
        return flow * u




# kineticFlow associated with beta
class KinFlow(nn.Module):
    def __init__(self, timeStep, sampleRange, numPoints):
        super().__init__()
        xRange = fe.fixrange([-sampleRange, sampleRange], 1)
        lapSym = fe.laplaciansymbol([numPoints], xRange)
        self.lapSymExpScal = torch.exp(1j * timeStep * torch.tensor(lapSym))

    def tcfft(self, f):
        return torch.fft.fftshift(torch.fft.fftn(f))

    def tcifft(self, f):
        return torch.fft.ifftn(torch.fft.ifftshift(f))

    def laplacianOpExp(self, lapsymbExp, s, u):
        esL = torch.pow(lapsymbExp, s)
        return self.tcifft(esL * self.tcfft(u))

    def forward(self, u, param):
        return self.laplacianOpExp(self.lapSymExpScal, param, u)


# -----------------------------------------------------------

# class Dataset(torch.utils.data.Dataset):
#     def __init__(self):
#     def __len__(self):
#     def __getitem__(self, idx):

# -----------------------------------------------------------


class Model(nn.Module):
    def __init__(
        self,
        alphaBeta,
        symSplit,
        totalTime,
        numSteps,
        potential,
        sampleRange,
        requires_grad=True,
    ):
        super(Model, self).__init__()

        self.numSteps = numSteps
        self.symSplit = symSplit
        self.numLayers = len(alphaBeta) + 2 if self.symSplit else (len(alphaBeta) // 2)
        self.params = nn.Parameter(
            data=torch.Tensor(alphaBeta), requires_grad=requires_grad
        )
        
        timeStep = totalTime / (self.numSteps)
        PotFlowScript = torch.jit.script(PotFlow(timeStep, potential))
        KinFlowScript = torch.jit.script(KinFlow(timeStep, sampleRange, len(potential)))
        # PotFlowScript = PotFlow(timeStep, potential)
        # KinFlowScript = KinFlow(timeStep, sampleRange, len(potential))
        self.potFlow = PotFlowScript
        self.kinFlow = KinFlowScript
        # for i in range(self.numLayers):
        #     self.potFlows.append(PotFlowScript(timeStep, potential))
        #     self.kinFlows.append(KinFlowScript(timeStep, sampleRange, len(potential)))

    def forward(self, u):
        if self.symSplit:
            alpha, beta = paramTransform(self.params)
        else:
            alpha = self.params[: self.numLayers]
            beta = self.params[self.numLayers :]

        assert len(alpha) == self.numLayers
        assert len(beta) == self.numLayers

        for i in range(self.numSteps):
            for j in range(self.numLayers):
                u = self.potFlow(u, alpha[j])
                u = self.kinFlow(u, beta[j])
        return u