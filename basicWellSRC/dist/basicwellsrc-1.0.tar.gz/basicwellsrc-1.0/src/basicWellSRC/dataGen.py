import numpy as np
import expsolve.fourier as fe
import torch
import json
import os.path
# TODO: fix Hack about working dir
# from src import model as md
import model as md

def gridGen(sampleRange, n):
    xRange = [-sampleRange, sampleRange]
    x = fe.grid1d(n, xRange)
    return x

def initCondGen(sampleRange, cent, x):
    xRange = [-sampleRange, sampleRange]
    u0 = lambda cent, x: np.exp(-(x-cent)**2/(2*0.25))
    # Eval
    u = u0(cent, x)
    # Norm
    u = u/fe.l2norm(u, xRange)
    return torch.Tensor(u)

def wellGen(x):
    well = lambda x: x**4 - 10*x**2
    # Eval
    v = well(x)
    return torch.Tensor(v)

def alphaBetaGen(splitLength, symSplit, splitType):
    # Add some more from here:
    # https://www.asc.tuwien.ac.at/~winfried/splitting/index.php?rc=0&ab=bm116-prk-ab&name=BM%2011-6%20PRK
    if symSplit:
        gamma = np.zeros(splitLength - 2)
        firstBetaInd = splitLength - splitLength//2 - 1
        if splitType in ['Strang', 'strang', 'leapfrog', 'leap', 'frog']:
            assert (splitLength >= 2)
        elif splitType in ['Yoshida-4', 'Yoshida4', 'Yosh4', 'yosh4']:
            assert (splitLength >= 4)
            omega = 1.0 / (2.0 - 2.0**(1.0/3.0))
            gamma[0:1] = [omega / 2.0]
            gamma[firstBetaInd:firstBetaInd+1] = [omega]
        else:
            assert False
    else:
        gamma = np.zeros(2* splitLength)
        if splitType in ['Trotter', 'trotter', 'sympEuler', 'Symp-Euler', 'symp-euler', 'SympEuler']:
            assert (splitLength >= 1)
            gamma[0:1] = 1.0
            gamma[splitLength:splitLength+1] = 1.0
        elif splitType in ['Strang', 'strang', 'leapfrog', 'leap', 'frog']:
            assert (splitLength >= 2)
            gamma[0:2] = [0.5, 0.5]
            gamma[splitLength:splitLength+1] = 1.0
        elif splitType in ['Yoshida-4', 'Yoshida4', 'Yosh4', 'yosh4']:
            assert (splitLength >= 4)
            omega = 1.0 / (2.0 - 2.0**(1.0/3.0))
            gamma[0:4] = [omega / 2.0, (1 - 2.0**(1.0/3.0)) * omega / 2.0, (1 - 2.0**(1.0/3.0)) * omega / 2.0, omega / 2.0]
            gamma[splitLength:splitLength+3] = [omega, -2.0**(1.0/3.0) * omega, omega]
        else:
            assert False
    
    return gamma

def makePriors(sampleRange, sampleDiscr, cent):

    grid = gridGen(sampleRange, sampleDiscr)
    initVals = initCondGen(sampleRange, cent, grid)
    pot = wellGen(grid)

    return grid, initVals, pot

def subset(u, nRef, nRefMult):
    # TODO: Duplicate code
    return u[0 + int(nRefMult / 2) : nRef - int(nRefMult / 2) : nRefMult]

def isStored(sampleRange, sampleDiscr, timeRange, timeDiscr, cent, centTol = 1e-14):
    fileName = 'data\\' + str(sampleRange) + '\\' + str(sampleDiscr) + '\\' + str(timeRange) + '\\' + str(timeDiscr)
    if not os.path.isdir(fileName):
        return False, ''
    
    dirsStr = os.listdir(fileName)
    dirs = [float(dir) for dir in dirsStr]
    dists = np.array([np.linalg.norm(dir - cent) for dir in dirs])
    minItr = np.argmin(dists)
    if (dists[minItr] > centTol):
        return False, ''
    
    fileName = os.path.join(fileName, dirsStr[minItr] + '\\data.json')
    return True, fileName

def getOrMakeRefData(sampleRange, sampleDiscr, timeRange, timeDiscr, cent, centTol = 1e-14, allowFinerTimeDiscr = True, allowFinerSampleDiscr = True, saveData = True, device = torch.device("cpu")):
    # TODO: figure out potential
    
    storedData = False
    storedPath = ''
    sampleDiscrMultRange = range(1, 100, 2) if allowFinerSampleDiscr else range(1, 2)
    for sampleDiscrMult in sampleDiscrMultRange:

        if not allowFinerTimeDiscr:
            storedData, storedPath = isStored(sampleRange, sampleDiscrMult*sampleDiscr, timeRange, timeDiscr, cent, centTol)
            if storedData:
                break

        fileName = 'data\\' + str(sampleRange) + '\\' + str(sampleDiscrMult*sampleDiscr) + '\\' + str(timeRange)
        if not os.path.isdir(fileName):
            continue
        
        timeDiscrsStr = os.listdir(fileName)
        timeDiscrs = np.array([int(timeDiscrStr) for timeDiscrStr in timeDiscrsStr if (int(timeDiscrStr) >= timeDiscr)])
        timeDiscrsSorted = np.argsort(timeDiscrs)
        for timeDiscrSorted in timeDiscrsSorted:
            storedData, storedPath = isStored(sampleRange, sampleDiscrMult*sampleDiscr, timeRange, timeDiscrs[timeDiscrSorted], cent, centTol)
            if storedData:
                break
        
        if storedData:
            break
    if storedData:
        # read Data
        print('Found Data at:' + storedPath)
        with open(storedPath, 'r', encoding='utf-8') as f:
            data = json.load(f)
            valsReal = np.array(data['valsReal'])
            valsImag = np.array(data['valsImag'])
            vals = valsReal + (1j*valsImag)
            vals = subset(vals, sampleDiscr*sampleDiscrMult, sampleDiscrMult)
            grid = subset(np.array(data['grid']), sampleDiscr*sampleDiscrMult, sampleDiscrMult)
            return torch.tensor(vals), data['cent'], grid

    grid, initVals, pot = makePriors(sampleRange, sampleDiscr, cent)
    alphaBeta = alphaBetaGen(2, False, 'Strang')

    model = md.Model(alphaBeta, False, timeRange, timeDiscr, pot, sampleRange, True, False).to(device)
    vals = model(initVals)

    if (saveData):
        # TODO: fix Hack about working dir
        fileName = 'data\\' + str(sampleRange) + '\\' + str(sampleDiscr) + '\\' + str(timeRange) + '\\' + str(timeDiscr) + '\\' + str(cent)
        try:
            os.makedirs(fileName, exist_ok=True)
        except Exception:
            pass

        fileName = os.path.join(fileName, 'data.json')
        with open(fileName, 'w', encoding='utf-8') as f:
            data = {}
            data['sampleRange'] = sampleRange
            # data['sampleDiscr'] = int(sampleDiscr)
            data['sampleDiscr'] = sampleDiscr
            data['timeRange'] = timeRange
            # data['timeDiscr'] = int(timeDiscr)
            data['timeDiscr'] = timeDiscr
            data['cent'] = cent
            data['grid'] = grid.tolist()
            data['initValsReal'] = initVals.tolist()
            data['initValsImag'] = np.zeros(len(initVals)).tolist()
            data['pot'] = pot.tolist()
            data['valsReal'] = np.real(vals.detach().numpy()).tolist()
            data['valsImag'] = np.imag(vals.detach().numpy()).tolist()
            json.dump(data, f, ensure_ascii=False, indent=4)
            f.close()

    return vals, cent, grid